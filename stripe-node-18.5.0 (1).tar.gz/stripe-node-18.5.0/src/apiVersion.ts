// File generated from our OpenAPI spec

export const ApiVersion = '2025-08-27.basil';
export const ApiMajorVersion = 'basil';
